// stdafx.h : include file for standard system include files,
// or project specific include files that are used frequently, but
// are changed infrequently
#pragma once

// Require Windows 2K API
#define _WIN32_WINNT 0x0500

#include <windows.h>
#include <Setupapi.h>
#include <Devguid.h>
#include <newdev.h>
